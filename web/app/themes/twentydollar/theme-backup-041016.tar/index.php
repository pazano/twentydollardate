<?php get_header(); ?>
	
	<div class="container">
		
		<?php if(get_theme_mod( 'sp_featured_slider' ) == true && !is_paged()) : ?>
			<?php get_template_part('inc/featured/featured'); ?>
		<?php endif; ?>
		
		<div id="content">
		
			<div id="main" <?php if(get_theme_mod('sp_sidebar_homepage') == true) : ?>class="fullwidth"<?php endif; ?>>
			
				<?php if(get_theme_mod('sp_home_layout') == 'grid' || get_theme_mod('sp_home_layout') == 'full_grid') : ?><ul class="sp-grid"><?php endif; ?>
				
				<?php 

					$paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
					$list_query = new WP_Query( 
						array(  
							'meta_query' => array(
								array(
									'key' => 'is_featured',
									'value' => '0',
									'compare' => '=='
								)
							), 
							'showposts' => 9,
							'paged' => $paged,
						) 
					); ?>
				
				<?php if ($list_query->have_posts()) : while ($list_query->have_posts()) : $list_query->the_post(); ?>
					
					<?php if(get_theme_mod('sp_home_layout') == 'grid') : ?>
					
						<?php get_template_part('content', 'grid'); ?>
					
					<?php elseif(get_theme_mod('sp_home_layout') == 'list') : ?>
					
						<?php get_template_part('content', 'list'); ?>
						
					<?php elseif(get_theme_mod('sp_home_layout') == 'full_list') : ?>
					
						<?php if( $list_query->current_post == 0 && !is_paged() ) : ?>
							<?php get_template_part('content'); ?>
						<?php else : ?>
							<?php get_template_part('content', 'list'); ?>
						<?php endif; ?>
					
					<?php elseif(get_theme_mod('sp_home_layout') == 'full_grid') : ?>
					
						<?php if( $list_query->current_post == 0 && !is_paged() ) : ?>
							<?php get_template_part('content'); ?>
						<?php else : ?>
							<?php get_template_part('content', 'grid'); ?>
						<?php endif; ?>
					
					<?php else : ?>
						
						<?php get_template_part('content'); ?>
						
					<?php endif; ?>	
						
				<?php endwhile; ?>
				
				<?php if(get_theme_mod('sp_home_layout') == 'grid' || get_theme_mod('sp_home_layout') == 'full_grid') : ?></ul><?php endif; ?>
				
				<?php solopine_pagination(); ?>
				
				<?php endif; ?>
				
			</div>

<?php if(get_theme_mod('sp_sidebar_homepage')) : else : ?><?php get_sidebar(); ?><?php endif; ?>
<?php get_footer(); ?>